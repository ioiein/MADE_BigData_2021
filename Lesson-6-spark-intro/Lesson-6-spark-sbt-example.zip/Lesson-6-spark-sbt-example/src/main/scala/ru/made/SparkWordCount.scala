package ru.made

import org.apache.spark.sql._
import org.apache.spark.sql.functions._

object SparkWordCount {
  def main(args: Array[String]): Unit = {
    // Создает сессию спарка
    val spark = SparkSession.builder()
      // адрес мастера
      .master("local[*]")
      // имя приложения в интерфейсе спарка
      .appName("made-demo")
      // взять текущий или создать новый
      .getOrCreate()

    // синтаксический сахар для удобной работы со спарк
    import spark.implicits._

    // прочитаем датасет https://www.kaggle.com/andrewmvd/trip-advisor-hotel-reviews

    val df = spark.read
      .option("header", "true")
      .option("inferSchema", "true")
      .csv("tripadvisor_hotel_reviews.csv")


    val flatten = df
      .select(explode(split('Review, " ")).alias("value"))

    //     df.cache() // позволяет сохранить промежуточные результаты в оперативной памяти
    //     df.persist(StorageLevel.MEMORY_AND_DISK) // аналогично, но нужно указывать StorageLevel, можно созранять на диск

    val counts = flatten
      .groupBy(col("value"))
      .count()
      .orderBy(desc("count"))

    counts.show
  }
}
